#!/usr/bin/python3

#导入 数据库 模块
import pymysql 
import re

#定义数据库操作帮助类
class DBHelper:

    __host = "localhost"
    __username = "root"
    __password = "19810109"
    __database = "pythondb"
    __conn = None
    __cursor = None
    __isTransaction = False

    #初始化数据库连接
    def __init__(self):
        try:
            self.__conn = pymysql.connect(self.__host,self.__username,self.__password,self.__database,charset="utf8")
            self.__cursor = self.__conn.cursor()
        except:
            raise "数据库连接错误"


    #执行sql语句，返回结果集
    def executeQuery(self,sql):
        try:
            self.__cursor.execute(sql)
            records = self.__cursor.fetchall()
            if self.__isTransaction == False:
                self.commit()
            return records
        except:
            print("Sql 执行失败 : ",sql)
            if self.__isTransaction == False:
                self.rollback()

    #执行sql语句，增删改
    def executeUpdate(self, sql):
        try:
            self.__cursor.execute(sql)
            if self.__isTransaction == False:
                self.commit()
            return True
        except:
            print("Sql 执行失败 : ",sql)
            if self.__isTransaction == False:
                self.rollback()
        return False
        
    #开启事务
    def beginTransaction(self):
        self.__isTransaction = True

    #事务提交
    def commit(self):
        self.__conn.commit()
        self.__isTransaction = False
        
    #事务回滚
    def rollback(self):
        self.__conn.rollback()
        self.__isTransaction = False
            
    #关闭数据库连接
    def close(self):
        try:
            if not self.__conn:
                self.__conn.close()
        except e:
            print("数据库连接关闭错误 : ",e)
