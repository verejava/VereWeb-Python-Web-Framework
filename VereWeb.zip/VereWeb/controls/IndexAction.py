
class IndexAction:

    def execute(self, request, response):
        
        name = "Hello World, 良好的启动是成功的开始"
        request.setAttribute("name", name) 
        
        return "success"
    