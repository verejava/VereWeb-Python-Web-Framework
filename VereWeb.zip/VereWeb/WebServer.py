import time
import sys
import os
from system.HttpResponse import HttpResponse
from system.HttpRequest import HttpRequest
from system.TemplateParser import TemplateParser
import urls
import settings
from system.CFile import CFile
import struct
from system.Interceptor import Interceptor
import selectors  
import socket
from system.DataTransport import DataTransport
from system.CharsetUtil import CharsetUtil
import uuid
import traceback

class WebServer:

    __transport = None
    __request = None
    __response = None

    def connection_made(self, transport):
        self.__transport = transport

    def data_received(self, data):
        try:
            if isinstance(data,bytes):
                self.doHandler(data.decode(settings.TRANSER_CHARSET,settings.TRANSER_METHOD), data)
            else:
                self.doHandler(data, data)
        except:
            info=sys.exc_info()  
            print(info[0],":",info[1])
            traceback.print_exc() 
        finally:
            self.__transport.close()
            
    def connection_lost(self, exc):
        self.__transport.close()
        
    def doHandler(self, data, bytesData):
        self.__request = HttpRequest(data, bytesData)
        
        #反射实例化 Action
        basePath = self.__request.getUri()
        methodName = "execute"
        actionName = ""
        if(basePath.find("!") > 0):
            actionName = basePath[basePath.rfind("/")+1: basePath.rfind("!")]
            methodName = basePath[basePath.rfind("!")+1:]
        else:
            actionName = basePath[basePath.rfind("/")+1:]
        
        # 判断是否是 action 请求
        if actionName in urls.urlActionMapping:
            self.__request.parseBody()
            session = self.__request.getSession()
            self.__response = HttpResponse(self.__transport, session, self.__request.getCookies())
            
            #检查 session 是否过期
            session.checkSessionExpire()
            
            #处理拦截器
            interceptorStatus = self.doInterceptor(self.__request, self.__response, actionName, methodName)
            
            if interceptorStatus == Interceptor.BREAK_REQUEST:
                return
                
            actionPath = urls.urlActionMapping[actionName]["action"]
            modulePath = actionPath[0:actionPath.rfind("/")]
            moduleName = actionPath[actionPath.rfind("/")+1:]
            sys.path.append(modulePath) # 导入action所在文件夹路径
            moduleClass = __import__(moduleName) # 导入action 模版
            # 反射实例化对象
            obj_class_name = getattr(moduleClass, moduleName)
            obj = obj_class_name()
            # 反射调用 action 方法
            method = getattr(obj, methodName)
            viewPageKey=method(self.__request, self.__response)
            if viewPageKey == None or viewPageKey == "":
                return
            
            # 转发到 视图 views 的页面
            htmlPage=urls.urlActionMapping[actionName][viewPageKey]
            htmlRealPath=os.path.realpath(htmlPage)
            htmlPageContent = CFile.readFile(htmlRealPath) # 
            resultHtml=TemplateParser().execHtml(self.__request,htmlPageContent) # 解析模版
            self.__response.write(resultHtml) # 返回到客户端
        else:
            self.__request.parseFile()
            self.__response = HttpResponse(self.__transport, self.__request.getSession(), self.__request.getCookies())
            self.__response.writeFile(self.__request.getFileShortPath(), self.__request.getRealPath())
            
    def doInterceptor(self, request, response, actionName, actionMethodName):
        interceptorStatus = Interceptor.OK
        length = len(urls.urlInteceptorList)
        for i in range(0, length):
            interceptorPath = urls.urlInteceptorList[i]
            modulePath = interceptorPath[0:interceptorPath.rfind("/")]
            moduleName = interceptorPath[interceptorPath.rfind("/")+1:]
            sys.path.append(modulePath) # 导入 interceptor 所在文件夹路径
            moduleClass = __import__(moduleName) # 导入 interceptor 模版
            # 反射实例化对象
            obj_class_name = getattr(moduleClass, moduleName)
            obj = obj_class_name()
            # 反射调用 interceptor 方法
            method = getattr(obj, "execute")
            interceptorStatus = method(self.__request, self.__response, actionName, actionMethodName)
            if interceptorStatus == Interceptor.OK:
                continue
            elif interceptorStatus == Interceptor.BREAK_INTERCEPTOR:
                break
            elif interceptorStatus == Interceptor.BREAK_REQUEST:
                break
                
        return interceptorStatus


def accept(sock,mask):
    conn,addr=sock.accept()
    #conn.setblocking(False)
    conn.settimeout(settings.RESPONSE_TIMEOUT)
    print("connection from {}".format(addr))
    selelctor.register(conn,selectors.EVENT_READ,read)
    
def read(conn,mask):
    selelctor.unregister(conn)
    webserver = WebServer()
    try:
        msg = b''
        filesize =settings.SOCKET_RECV_BUFF_SIZE
        data = conn.recv(filesize)
        
        decodeData = data.decode(settings.TRANSER_CHARSET,settings.TRANSER_METHOD)
        if decodeData.find("Host:") <0:
            return
        
        contentLength = 0
        contentLengthIndex = decodeData.find("Content-Length:")
        if contentLengthIndex > 0:
            decodeData = decodeData[decodeData.find("Content-Length:")+15:]
            contentLength = int(decodeData[0:decodeData.find("\r\n")].strip())

        length = len(data)
        if contentLength > filesize:
            while length != 0:
                msg +=data
                data = conn.recv(filesize)
                length = len(data)
                if length < filesize:
                    msg +=data
                    break
        else:
            msg +=data

        webserver.connection_made(DataTransport(conn))
        webserver.data_received(msg)
        
    except:
        info=sys.exc_info()  
        print(info[0],":",info[1])
        traceback.print_exc() 
    finally:
        if not conn:
            conn.close()


sock=socket.socket()
sock.bind(('localhost',settings.SERVER_PORT))
sock.listen(settings.MAX_CONCURRENT_NUMBER)
sock.setsockopt(socket.SOL_SOCKET,socket.SO_RCVBUF, settings.SOCKET_RECV_BUFF_SIZE)
sock.setblocking(False)
selelctor=selectors.DefaultSelector() 
selelctor.register(sock, selectors.EVENT_READ, accept)  #注册功能
print("Python WebServer Startup ",settings.SERVER_PORT,"......")

while True:
    events=selelctor.select()  

    for key,mask in events:
        func=key.data
        obj=key.fileobj
        func(obj,mask)