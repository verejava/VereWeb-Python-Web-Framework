# 拦截器列表 按顺序执行拦截 Action
urlInteceptorList = [
                        "interceptor/DefaultInterceptor"
                    ]
                       
# 网址映射转发
urlActionMapping = {
                    "index":{
                            "action":"controls/IndexAction", 
                            "success":"index.html"
                            }
                    } 