from system.Cookie import Cookie
import datetime
import os
import settings
import time

class HttpResponse:

    __transport = None
    __http = "HTTP/1.1"
    __httpProtocal = __http + " 200 OK"
    __contentType = "text/html"
    __charset = "utf-8"
    __cookies = [] # 原始 cookie
    __responseCookies = [] # 需要返回到客户端的 cookie
    __session = {}

    def __init__(self, transport, session, cookies):
        self.__transport = transport
        self.__cookies = cookies
        self.__session = session
        
        if self.__session != None and self.__session.checkSessionIdExsit() == False:
            self.addCookie(Cookie("PSESSIONID", self.__session.getSessionId()))
        
    def addCookie(self, cookie):
        self.__responseCookies.append(cookie)
        self.__cookies.append(cookie)
        
    # 先删除 在添加
    def setCookie(self, cookie):
        self.deleteCookie(cookie.getKey())
        self.addCookie(cookie)
                
    def deleteCookie(self, key):
        now = datetime.datetime.now()
        delta = datetime.timedelta(days=-3)
        n_days = now + delta
        expiration = n_days.strftime("%a, %d-%b-%Y %H:%M:%S GMT")

        length = len(self.__responseCookies)
        for i in range(0,length):
            item = self.__responseCookies[i]
            if key == item.getKey():
                item.setExpire(expiration)
                break;
        
        length = len(self.__cookies)        
        for i in range(0,length):
            item = self.__cookies[i]
            if key == item.getKey():
                item.setExpire(expiration)
                del item
                break;
                
    def sendRedirect(self, page):
        msgList = []
        msgList.append(self.__http+" 302 OK")
        msgList.append("\r\n")

        self.__writeCookie(msgList)
            
        msgList.append("Location: ")
        msgList.append(page)
        msgList.append("\r\n")
        
        msgList.append("content-type: ")
        msgList.append(self.__contentType)
        msgList.append("; charset=")
        msgList.append(self.__charset)
        msgList.append("\r\n\r\n")
        
        sendMesssage = "".join(msgList).encode(self.__charset)
        self.__transport.write(sendMesssage)
        
    def writeFile(self, fileName, realpath):
        msgList = []
        msgList.append(self.__http+" 200 OK")
        msgList.append("\r\n")
        
        self.__writeCookie(msgList)

        fileNameLower = fileName.lower()
        dotIndex = fileNameLower.rfind(".")
        fileExt = ""
        if dotIndex > 0:
            fileExt = fileNameLower[dotIndex:]
        contentType = "text/html"
        if fileExt != "" and fileExt in settings.FILE_EXT_DICT:
            contentType = settings.FILE_EXT_DICT[fileExt]
            
        msgList.append("content-type: ")
        msgList.append(contentType)
        msgList.append("\r\n")
        msgList.append("Accept-Range: ")
        msgList.append("bytes")
        msgList.append("\r\n")
        
        
        GMT_FORMAT =  '%a, %d %b %Y %H:%M:%S GMT'
            
        now = datetime.datetime.utcnow()
        currentDate = now.strftime(GMT_FORMAT)
        
        delta = datetime.timedelta(seconds=19)
        n_days = now + delta
        expireDate = n_days.strftime(GMT_FORMAT)
        
        last_modifed = currentDate
        if os.path.exists(realpath) and os.path.isfile(realpath):
            last_modifed = time.strftime(GMT_FORMAT, time.localtime(os.stat(realpath).st_mtime))

        msgList.append("Cache-Control: public")
        msgList.append("\r\n")
        msgList.append("Last-Modified: " + last_modifed)
        msgList.append("\r\n")
        msgList.append("Date: " + currentDate)
        msgList.append("\r\n")
        msgList.append("Expires: " + expireDate)
        msgList.append("\r\n")

        
        filePath=os.path.realpath(fileName)
        fileSize = 0
        fileContent = ""
        if os.path.exists(filePath) and os.path.isfile(filePath):
            fileSize = os.path.getsize(filePath)
            f = open(filePath, 'rb')
            fileContent = f.read()
            f.close()
            msgList.append("Content-Length: ")
            msgList.append(str(fileSize))
            msgList.append("\r\n\r\n")
        
        sendMesssage = "".join(msgList).encode(self.__charset)
        self.__transport.write(sendMesssage)
        if isinstance(fileContent,str):
            self.__transport.write(fileContent.encode(self.__charset))
        else:
            self.__transport.write(fileContent)
        
		
    def write(self, message):
        msgList = []
        msgList.append(self.__httpProtocal)
        msgList.append("\r\n")

        self.__writeCookie(msgList)
        
        msgList.append("content-type: ")
        msgList.append(self.__contentType)
        msgList.append("; charset=")
        msgList.append(self.__charset)
        msgList.append("\r\n\r\n")
        
        msgList.append(message)
        sendMesssage = "".join(msgList).encode(self.__charset)
        self.__transport.write(sendMesssage)
        
        
    def __writeCookie(self, msgList):
        length = len(self.__responseCookies)
        for i in range(0,length):
            item = self.__responseCookies[i]
            msgList.append("Set-Cookie: ")
            msgList.append(item.getKey())
            msgList.append("=")
            msgList.append(item.getValue())
            msgList.append(";")
            msgList.append("path")
            msgList.append("=")
            msgList.append(item.getPath())
            msgList.append(";")
            msgList.append("expires")
            msgList.append("=")
            msgList.append(item.getExpire())
            msgList.append(";\r\n")
        