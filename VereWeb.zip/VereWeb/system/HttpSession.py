import time
from system.CFile import CFile
import uuid
from Cookie import Cookie
import settings

class HttpSession:

    __dictionary = {}
    __psessionId = ""
    __expire = 0
    __setCookieList = []
    __sessionIdExsit = False
	
    def __init__(self, setCookieList):
        self.__setCookieList = setCookieList
        
        #检查是否 存在 PSESSIONID ，如果存在获得 PSESSIONID
        length = len(self.__setCookieList)
        for i in range(0, length):
            item = self.__setCookieList[i]
            if "PSESSIONID" == item.getKey():
                self.__psessionId = item.getValue()
                break

        if self.__psessionId == "":
            self.__psessionId = str(uuid.uuid1())
        else:
            self.__sessionIdExsit =True
    
    def getSessionId(self):
        return self.__psessionId
        
    # 检查从客户端获得的原始 cookie 里面是否包含 sessionId
    def checkSessionIdExsit(self):
        return self.__sessionIdExsit
        
    def checkSessionExpire(self):
        self.__dictionary = CFile.readSession()
        #判断session 是否过期
        if self.__psessionId in self.__dictionary:
            createtime = self.__dictionary.get(self.__psessionId).get("createtime",0)
            expire = time.time() - createtime
            if expire >= settings.SESSION_EXPIRE:
                del self.__dictionary[self.__psessionId]
                CFile.writeSession(self.__dictionary)
            
    def getAttribute(self, key):
        self.__dictionary = CFile.readSession()
        if (self.__psessionId in self.__dictionary) == False:
            return ""
        else:
            return self.__dictionary.get(self.__psessionId).get(key)
        
    def setAttribute(self, key, value):
        self.__dictionary = CFile.readSession()
        if (self.__psessionId in self.__dictionary) == False:
            self.__dictionary[self.__psessionId] = {}
            self.__dictionary[self.__psessionId]["createtime"] = time.time() # session 创建时间
        self.__dictionary[self.__psessionId][key] = value
        CFile.writeSession(self.__dictionary)
        
    def removeAttribute(self, key):
        self.__dictionary = CFile.readSession()
        if (self.__psessionId in self.__dictionary) == True:
            if (key in self.__dictionary[self.__psessionId]) == True:
                self.__dictionary[self.__psessionId].pop(key)
        CFile.writeSession(self.__dictionary)
        
        
    