
class FileItem:
    __fileName = ""
    __fileDirectory = ""
    __filePath = ""
    __fileSize = 0
    __fieldName = ""
    
    def getFileName(self):
        return self.__fileName
        
    def setFileName(self, fileName):
        self.__fileName = fileName
        
    def getFileDirectory(self):
        return self.__fileDirectory
        
    def setFileDirectory(self, fileDirectory):
        self.__fileDirectory = fileDirectory
        
    def getFilePath(self):
        return self.__filePath
        
    def setFilePath(self, filePath):
        self.__filePath = filePath
        
    def getFileSize(self):
        return self.__fileSize
        
    def setFileSize(self, fileSize):
        self.__fileSize = fileSize
        
    def getFieldName(self):
        return self.__fieldName
        
    def setFieldName(self, fieldName):
        self.__fieldName = fieldName