import sys
import os
sys.path.append("system")
from HttpSession import HttpSession
from Cookie import Cookie
import settings
from FileItem import FileItem
from system.CFile import CFile
import tempfile
import urllib.parse
from system.CharsetUtil import CharsetUtil

class HttpRequest:

    __data = ""
    __url = ""
    __uri = ""
    __method = ""
    __userAgent = ""
    __accept = ""
    __language = ""
    __httpProtocol = ""
    __shortUrl = ""
    __host = ""
    __paramDictionary = {}
    __paramFileList = []
    __paramGet = ""
    __paramPost = ""
    __setCookieList = []
    __session = None
    __cookie = None
    __attributeDictionary = {}
    __bodyDictionay = {}
    __headerData = ""
    __formData = ""
    __isFileUpload = False
    __bytesData = b""
	
    def __init__(self, data, bytesData):
        self.__data = data
        self.__bytesData = bytesData
        
        #判断是否有文件上传
        if self.__data.find("multipart/form-data") > 0:
            self.__isFileUpload = True
            
        self.__headerData = ""
        self.__formData = ""
        if self.__isFileUpload ==True:
            splitPosition = self.__data.find("Content-Disposition: form-data;")
            self.__headerData = self.__data[0:splitPosition]
            self.__formData = self.__data[splitPosition:]
        else:
            self.__headerData = self.__data
            
        headList = self.__headerData.split("\r\n")
        firstHeadList = headList[0].split(" ") # 获得头部 GET 或 POST
        self.__method = firstHeadList[0]
        self.__shortUrl = firstHeadList[1]
        self.__httpProtocol = firstHeadList[2]
        
       
        #封装信息体字典
        self.parseBodyDictionay(headList)
        
        # 解析头 
        self.parseUri()
        
    def parseBodyDictionay(self, headList):
        if self.__method.lower().find("get") >= 0:
            # 将头部信息封装成 字典 self.__bodyDictionay
            length = len(headList)
            for i in range(1, length):
                if headList[i].strip() == "":
                    continue
                bodyList = headList[i].split(": ")
                self.__bodyDictionay[bodyList[0]] = bodyList[1].strip()
        elif self.__isFileUpload == True:
            # 将头部信息封装成 字典 self.__bodyDictionay
            length = len(headList)
            for i in range(1, length - 2):
                if headList[i].strip() == "":
                    continue
                bodyList = headList[i].split(": ")
                self.__bodyDictionay[bodyList[0]] = bodyList[1].strip()
        else:
            # 将头部信息封装成 字典 self.__bodyDictionay
            length = len(headList)
            for i in range(1, length - 1):
                if headList[i].strip() == "":
                    continue
                bodyList = headList[i].split(": ")
                self.__bodyDictionay[bodyList[0]] = bodyList[1].strip()
            self.__paramPost = headList[length - 1]
		
    def parseUri(self):
        self.__host = self.__bodyDictionay.get("Host","")
        self.__userAgent = self.__bodyDictionay.get("User-Agent","")
        self.__accept = self.__bodyDictionay.get("Accept","")
        self.__url = "".join([self.__httpProtocol[0:self.__httpProtocol.find("/")].lower(),"://",self.__host,self.__shortUrl])
        
        self.__uri = self.__url
        questionIndex = self.__url.find("?")
        if questionIndex > 0:
            self.__uri = self.__url[0:questionIndex]
        
    def parseParam(self):
        self.__paramDictionary = {}
        self.__paramFileList = []
        if self.__method.lower().find("get") >= 0:
            self.parseParamGet()
        elif self.__isFileUpload == True:
            self.parseParamGet()
            self.parseParamPostAndFile()
        else:
            self.parseParamGet()
            self.parseParamPost()
            
                
    def parseParamGet(self):
        questionIndex = self.__url.find("?")
        if questionIndex > 0:
            self.__paramGet = self.__url[(questionIndex+1):]
            paramList = self.__paramGet.split("&")
            for item in paramList:
                itemList = item.split("=")
                key = itemList[0]
                value = itemList[1]
                value = self.transerSpecialStr(value)
                self.__paramDictionary[key] = value
               
    def parseParamPost(self):
        if self.__paramPost != "":
            paramList = self.__paramPost.split("&")
            for item in paramList:
                itemList = item.split("=")
                key = itemList[0]
                value = itemList[1]
                value = self.transerSpecialStr(value)
                if key in self.__paramDictionary.keys():
                    self.__paramDictionary[key] = self.__paramDictionary[key]+","+value
                else:
                    self.__paramDictionary[key] = value
                
    def parseParamPostAndFile(self):
        formDataList = self.__formData.split("Content-Disposition: form-data;")
        length = len(formDataList)
        for i in range(1, length):
            item = formDataList[i]
            if item.find("filename=") > 0:
                pass
            else:
                #获得 form-data  name = value
                startIndex = item.find("name=\"")+6
                itemSub = item[startIndex:]
                endIndex = itemSub.find("\"")
                key = itemSub[0:endIndex]
                value = itemSub[endIndex+1:itemSub.find("----")].strip()
                value = self.transerSpecialStr(value)
                value = bytes(value,settings.TRANSER_CHARSET).decode(settings.CHARSET,settings.TRANSER_METHOD)
                if key in self.__paramDictionary.keys():
                    self.__paramDictionary[key] = self.__paramDictionary[key]+","+value
                else:
                    self.__paramDictionary[key] = value
                    
        self.parseParamOriginalFile()
                    
    def parseParamOriginalFile(self):
        formDataList = self.__bytesData.split(b"Content-Disposition: form-data;")
        length = len(formDataList)
        for i in range(1, length):
            item = formDataList[i]
            if item.find(b"filename=") > 0:
                #获得 form-data  name = value
                fileItem = FileItem()
                
                startIndex = item.find(b"name=\"")+6
                itemSub = item[startIndex:]
                endIndex = itemSub.find(b"\"")
                key = itemSub[0:endIndex].decode(settings.CHARSET)
                fileItem.setFieldName(key)
                
                startIndex = item.find(b"filename=\"")+10
                itemSub = item[startIndex:]
                endIndex = itemSub.find(b"\"")
                filename = itemSub[0:endIndex].decode(settings.CHARSET)
                print("filename = ",filename)
                if filename != "":
                    fileItem.setFileName(filename)
                    
                    #获得文件内容
                    fileContent = item[item.find(b"Content-Type:"):]
                    fileContent = fileContent[fileContent.find(b"\r\n"):fileContent.find(b"----")]
                    fileContent = fileContent[4:fileContent.rfind(b"\r\n")] # 去掉前面 2 个 \r\n 后面 1 个 \r\n
                    
                    tempDir = tempfile.gettempdir()
                    tempFile = tempDir+"/"+filename # 临时文件绝对路径
                    CFile.writeFile(tempFile, fileContent)# 保存临时文件
                    tempFileSize = os.path.getsize(tempFile)# 临时文件大小
                    
                    fileItem.setFileDirectory(tempDir)
                    fileItem.setFilePath(tempFile)
                    fileItem.setFileSize(tempFileSize)
                
                self.__paramFileList.append(fileItem)
            
                    
    def transerSpecialStr(self, str):
        data = str
        data = data.replace("'","\\\'")
        data = data.replace("\"","\\\"")
        return data
        
    def parseBody(self):
        self.parseParam()
    
        self.__language = self.__bodyDictionay.get("Accept-Language","")
        
        self.parseCookie()
        
    def parseFile(self):
        self.parseParam()
    
        self.__language = self.__bodyDictionay.get("Accept-Language","")
        
    def parseCookie(self):
        
        self.__cookie = self.__bodyDictionay.get("Cookie", "")
        if self.__cookie != "":
            cookieList = self.__cookie.split(";")
            length = len(cookieList)
            for i in range(0, length):
                item = cookieList[i]
                nameValueList = item.split("=")
                self.__setCookieList.append(Cookie(nameValueList[0], nameValueList[1]))
        
        #封装 session
        self.__session = HttpSession(self.__setCookieList)
        
        
    def getMethod(self):
        return self.__method
        
    def getShortUrl(self):
        return self.__shortUrl
        
    def getFileShortPath(self):
        return self.__shortUrl[1:]
        
    def getRealPath(self):
        return os.path.realpath(self.getFileShortPath())
        
    def getHttpProtocol(self):
        return self.__httpProtocol
        
    def getHost(self):
        return self.__host
        
    def getUserAgent(self):
        return self.__userAgent
        
    def getAccept(self):
        return self.__accept
        
    def getUrl(self):
        return self.__url
        
    def getUri(self):
        return self.__uri
        
    def getLanguage(self):
        return self.__language
        
    def getParameter(self, name):
        value = self.__paramDictionary.get(name,"")
        value = urllib.parse.unquote(value)
        return value
        
    def getFile(self, name):
        if self.__isFileUpload == True:
            length = len(self.__paramFileList)
            for i in range(0, length):
                fileItem = self.__paramFileList[i]
                if fileItem.getFieldName() == name:
                    return fileItem
                
        return None
        
    def getFileList(self):
        fileList = []
        if self.__isFileUpload == True:
            length = len(self.__paramFileList)
            for i in range(0, length):
                fileItem = self.__paramFileList[i]
                fileList.append(fileItem)
        return fileList
        
    def getSession(self):
        return self.__session
        
    def getCookies(self):
        return self.__setCookieList
        
    def getCookie(self,key):
        length = len(self.__setCookieList)
        for i in range(0, length):
            item = self.__setCookieList[i]
            if key == item.getKey():
                return item
        return None
        
    def getAttribute(self, key):
        return self.__attributeDictionary.get(key, "")
        
    def setAttribute(self, key, value):
        self.__attributeDictionary[key] = value
        
    def getAttributeDictionary(self):
        return self.__attributeDictionary