
class Interceptor:

    BREAK_INTERCEPTOR = 0 # 终止后面拦截器执行
    BREAK_REQUEST = 1 # 终止后面所有执行
    OK = 200 # 继续往下执行

    def execute(self, request, response, actionName, methodName):
    
        return Interceptor.OK
