
class DataTransport:

    __conn = None
    
    def __init__(self, conn):
        self.__conn = conn
        
    def write(self, msg):
        self.__conn.send(msg)
        
    def close(self):
        self.__conn.close()
        