import settings
import os
import tempfile
import settings

class CharsetUtil:


    @staticmethod
    def decodeByteToString(b):
        str = "%s" % b
        return str

        
    @staticmethod
    def decodeStringToByte(s):
        b = "%b" % s
        return b
        
    @staticmethod
    def decodeStringToByteToString(s):
        b = "%b" % s
        return b.decode(settings.CHARSET,settings.TRANSER_METHOD)
   