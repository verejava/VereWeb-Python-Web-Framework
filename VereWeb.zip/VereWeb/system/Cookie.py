import uuid

class Cookie:
    __key = ""
    __value = ""
    __path = "/"
    __domain = "."
    __expire = "0"
	
    def __init__(self, key, value):
        self.__key = key
        self.__value = value
        
    def getKey(self):
        return self.__key
        
    def setKey(self, key):
        self.__key = key
        
    def getValue(self):
        return self.__value
        
    def setValue(self, value):
        self.__value = value
        
    def getPath(self):
        return self.__path
        
    def setPath(self, path):
        self.__path = path
        
    def getDomain(self):
        return self.__domain
        
    def setDomain(self, domain):
        self.__domain = domain
        
    def getExpire(self):
        return self.__expire
        
    def setExpire(self, expire):
        self.__expire = expire