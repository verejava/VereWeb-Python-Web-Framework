import settings
import os
import tempfile

SESSION_FILENAME = "session.tmp"

class CFile:

    # 读取 session 内容
    @staticmethod
    def readSession():
        session_path=tempDir = tempfile.gettempdir()+"/"+SESSION_FILENAME

        sessionContent = ""
        # 如果没有创建空文件
        if os.path.exists(session_path):
            f = open(session_path, "r", encoding=settings.CHARSET)
            try:
                sessionContent = f.read()
            finally:
                f.close()
        
        if sessionContent == None or sessionContent == "" or sessionContent == 0:
            sessionContent = "{}"
        return eval(sessionContent)
    
    # 写入 session 内容
    @staticmethod
    def writeSession(content):
        session_path=tempDir = tempfile.gettempdir()+"/"+SESSION_FILENAME
        f = open(session_path, "w", encoding=settings.CHARSET)
        try:
            f.write(str(content))
            f.flush()
        finally:
            f.close()
        
    def checkSessionExsit(self, psessionId):
        self.__dictionary = CFile.readSession()
        if self.__dictionary.get(self.__psessionId) == None:
            return False
        else:
            return True
    
    # 读取 文件 内容
    @staticmethod
    def readFile(path):
        fileContent = ""
        f = open(path, "r", encoding=settings.CHARSET)
        try:
            fileContent = f.read()
        finally:
            f.close()
        return fileContent
        
    # 内容写入 文件
    @staticmethod
    def writeFile(path, content):
        f = open(path, "wb")
        try:
            f.write(content)
        finally:
            f.close()
            
