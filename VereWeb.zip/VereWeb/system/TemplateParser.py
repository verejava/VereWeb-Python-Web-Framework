from string import Template

class TemplateParser(object):

    def execHtml(self, request, htmlTempate):
        attributes = request.getAttributeDictionary()
        
        for key,value in attributes.items():
            name = "{$"+str(key)+"}"
            replaceValue = str(value)
            htmlTempate = htmlTempate.replace(name,replaceValue)
            
        return htmlTempate
