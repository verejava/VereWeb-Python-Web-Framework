from system.Interceptor import Interceptor

class DefaultInterceptor(Interceptor):

    def execute(self, request, response, actionName, methodName):
        
        return Interceptor.OK
